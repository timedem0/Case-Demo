import React, { Component } from 'react';

export default class AddCategory extends Component {

  render() {
    return (
      <div>
        <p>
          <button type="button">ADD NEW CATEGORY</button>
        </p>
      </div>
    );
  }
}