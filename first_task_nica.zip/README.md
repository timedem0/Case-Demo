React Introduction and Recap task

Tudor Nica, 1703081

New things that I learned while completing this task:
- How to export a single function separately
- How to create a tidy minimalistic model file
- How to separate components into more fine grain
- How to get more comfortable working with a multi level directory structure
